//package Adam6015;
//V1.20: Tim.Lin modify
//2008/09/23
//Modify DecimalFormat value
//Modify Average value bug

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import java.lang.*;
import java.net.*;
import java.net.InetAddress;
import javax.swing.border.*;
import java.text.*;			//Tim.Lin add for "DecimalFormat"
/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:
 * @author
 * @version 1.0
 */

public class Adam6015 extends Applet implements Runnable{
  boolean isStandalone = false;
  boolean PWIsCorrect = false;
  boolean IsPWLogin = false;
  Thread AdamPoilThread;
  String HostIP;// "172.18.1.212";
  byte UserPassWordArray[] = new byte[8];	
  boolean IsAdamRuning = false;
  boolean IsAdamDOoutRuning = false;

  boolean IsFirsTime = true;
  int Adam6015EachChannelType[] = new int[9];

  String Adam6015Type_Up[] = new String[14];
  String Adam6015Type_Down[] = new String[14];
  float Adam6015Span[] = new float[14];
  float Adam6015Zero[]  = new float[14];

  String Adam6015_UserDefineSpanVal[] = new String[8];
  String Adam6015_UserDefineZeroVal[]  = new String[8];

  ModBus Adam6015Connection;// = new ModBus(HostIP);

  JLabel JLabel1 = new JLabel();

  Led LedDO0 = new Led();
  Led LedDO1 = new Led();
  Led CommLed = new Led(java.awt.Color.orange.darker().darker(), java.awt.Color.orange.darker().darker().darker().darker().darker());

  //User password login windows layout	2002/8/23
  myFramPanel palMessageWindow = new myFramPanel(3, " Message ", 62);	
  JLabel LabMessage = new JLabel("Please enter your password:");
  JTextField txtUserPassword = new JTextField("");
  JButton btPW_Apply = new JButton("OK");

  JLabel labNormal = new JLabel("Normal");
  JLabel labMaximum = new JLabel("Max");
  JLabel labMinimum = new JLabel("Min");
  JLabel labResetMaximum = new JLabel("Reset");
  JLabel labResetMinimum = new JLabel("Reset");

  JLabel labAI0 = new JLabel("Ch0");
  JLabel labAI1 = new JLabel("Ch1");
  JLabel labAI2 = new JLabel("Ch2");
  JLabel labAI3 = new JLabel("Ch3");
  JLabel labAI4 = new JLabel("Ch4");
  JLabel labAI5 = new JLabel("Ch5");
  JLabel labAI6 = new JLabel("Ch6");
  JLabel labAIAvg = new JLabel("Avg");  
  
  JLabel labTypeAI0_Up = new JLabel();//("Pt385 -50~+150");
  JLabel labTypeAI1_Up = new JLabel();//("Pt385 -50~+150");
  JLabel labTypeAI2_Up = new JLabel();//("Pt385 -50~+150");
  JLabel labTypeAI3_Up = new JLabel();//("Pt385 -50~+150");
  JLabel labTypeAI4_Up = new JLabel();//("Pt385 -50~+150");
  JLabel labTypeAI5_Up = new JLabel();//("Pt385 -50~+150");
  JLabel labTypeAI6_Up = new JLabel();//("Pt385 -50~+150");
  JLabel labTypeAIAvg_Up = new JLabel();//("Pt385 -50~+150");  
  
  JLabel labTypeAI0_Down = new JLabel();//("Pt385 -50~+150");
  JLabel labTypeAI1_Down = new JLabel();//("Pt385 -50~+150");
  JLabel labTypeAI2_Down = new JLabel();//("Pt385 -50~+150");
  JLabel labTypeAI3_Down = new JLabel();//("Pt385 -50~+150");
  JLabel labTypeAI4_Down = new JLabel();//("Pt385 -50~+150");
  JLabel labTypeAI5_Down = new JLabel();//("Pt385 -50~+150");
  JLabel labTypeAI6_Down = new JLabel();//("Pt385 -50~+150");
  JLabel labTypeAIAvg_Down = new JLabel();//("Pt385 -50~+150");  

  JTextField txtAICh0Value = new JTextField("00.000");
  JTextField txtAICh1Value = new JTextField("00.000");
  JTextField txtAICh2Value = new JTextField("00.000");
  JTextField txtAICh3Value = new JTextField("00.000");
  JTextField txtAICh4Value = new JTextField("00.000");
  JTextField txtAICh5Value = new JTextField("00.000");
  JTextField txtAICh6Value = new JTextField("00.000");
  JTextField txtAIAvgValue = new JTextField("00.000");  
  
  JTextField txtAIMaxCh0Value = new JTextField("00.000");
  JTextField txtAIMaxCh1Value = new JTextField("00.000");
  JTextField txtAIMaxCh2Value = new JTextField("00.000");
  JTextField txtAIMaxCh3Value = new JTextField("00.000");
  JTextField txtAIMaxCh4Value = new JTextField("00.000");
  JTextField txtAIMaxCh5Value = new JTextField("00.000");
  JTextField txtAIMaxCh6Value = new JTextField("00.000");
  JTextField txtAIMaxAvgValue = new JTextField("00.000");
  
  JTextField txtAIMinCh0Value = new JTextField("00.000");
  JTextField txtAIMinCh1Value = new JTextField("00.000");
  JTextField txtAIMinCh2Value = new JTextField("00.000");
  JTextField txtAIMinCh3Value = new JTextField("00.000");
  JTextField txtAIMinCh4Value = new JTextField("00.000");
  JTextField txtAIMinCh5Value = new JTextField("00.000");
  JTextField txtAIMinCh6Value = new JTextField("00.000");
	
  CheckboxGroup cbg = new CheckboxGroup();
  Checkbox ChkIsEng = new Checkbox("Eng", cbg, true);
  Checkbox ChkIsHex = new Checkbox("Hex", cbg, false);  
  Checkbox ChkIsUserDefine = new Checkbox("User Define", cbg, false);  


  JLabel labAIMinAvg = new JLabel("Avg");
  JTextField txtAIMinAvgValue = new JTextField("00.000");

  JButton btDO0 = new JButton("DO0");
  JButton btDO1 = new JButton("DO1");
  
  JButton btRetMaxCh0 = new JButton("Ch0");
  JButton btRetMaxCh1 = new JButton("Ch1");
  JButton btRetMaxCh2 = new JButton("Ch2");
  JButton btRetMaxCh3 = new JButton("Ch3");
  JButton btRetMaxCh4 = new JButton("Ch4");
  JButton btRetMaxCh5 = new JButton("Ch5");
  JButton btRetMaxCh6 = new JButton("Ch6");
  JButton btRetMaxCh8 = new JButton("Ch8");
  
  JButton btRetMinCh0 = new JButton("Ch0");
  JButton btRetMinCh1 = new JButton("Ch1");
  JButton btRetMinCh2 = new JButton("Ch2");
  JButton btRetMinCh3 = new JButton("Ch3");
  JButton btRetMinCh4 = new JButton("Ch4");
  JButton btRetMinCh5 = new JButton("Ch5");
  JButton btRetMinCh6 = new JButton("Ch6");
  JButton btRetMinCh8 = new JButton("Ch8");

  myFramPanel palAIOStatus = new myFramPanel(2);

  myFramPanel palAI = new myFramPanel(3, " Adam AI Status ", 95);  
  myFramPanel palMaxAI = new myFramPanel(3, " Adam Max AI Status ", 119);
  myFramPanel palMinAI = new myFramPanel(3, " Adam Min AI Status ", 119);

  myFramPanel palDO = new myFramPanel(3, " Adam DO Status ", 100);  
  myFramPanel palAdamStatus = new myFramPanel(1);

  //JButton btDO5 = new JButton("DO5");
  //JButton btDO4 = new JButton("DO4");
  //Led LedDO5 = new Led();
  //Led LedDO4 = new Led();

  JLabel labAdamStatusForDIO = new JLabel("Status : ");
  /*
  JLabel labAIHighByteValue = new JLabel("High Byte (Hex)");
  JLabel labAILowByteValue = new JLabel("Low Byte (Hex)");
  JTextField txtDIHighByteValue = new JTextField("");
  JTextField txtDILowByteValue = new JTextField("");
  */

  JTextField txtDOLowByteValue = new JTextField("");
  JLabel labDOLowByteValue = new JLabel("Low Byte (Hex)");

  /**Get a parameter value*/
  public String getParameter(String key, String def) {
    return isStandalone ? System.getProperty(key, def) :
      (getParameter(key) != null ? getParameter(key) : def);
  }

  public void InitAdam6015StartValue() {		
      int i, tmp;
      byte ModBusRTU[] = new byte[128];

		Adam6015Type_Up[0] =		"  Pt385  ";
		Adam6015Type_Down[0] =	" -50~+150";
		Adam6015Span[0] = (float)150.0;
		Adam6015Zero[0] = (float)-50.0;

		Adam6015Type_Up[1] =		"  Pt385  ";
		Adam6015Type_Down[1] =	"  0~+100 ";
		Adam6015Span[1] = (float)100.0;
		Adam6015Zero[1] = (float)-0.0;

		Adam6015Type_Up[2] =		"  Pt385  ";
		Adam6015Type_Down[2] =	"  0~+200 ";
		Adam6015Span[2] = (float)200.0;
		Adam6015Zero[2] = (float)0.0;

		Adam6015Type_Up[3] =		"  Pt385  ";
		Adam6015Type_Down[3] =	"  0~+400 ";
		Adam6015Span[3] = (float)400.0;
		Adam6015Zero[3] = (float)0.0;

		Adam6015Type_Up[4] =		"  Pt385  ";
		Adam6015Type_Down[4] =	" -200~+200";
		Adam6015Span[4] = (float)200.0;
		Adam6015Zero[4] = (float)-200.0;

		Adam6015Type_Up[5] =		"  Pt392  ";
		Adam6015Type_Down[5] =	" -50~+150 ";
		Adam6015Span[5] = (float)150.0;
		Adam6015Zero[5] = (float)-50.0;

		Adam6015Type_Up[6] =		"  Pt392  ";
		Adam6015Type_Down[6] =	"  0~+100 ";
		Adam6015Span[6] = (float)100.0;
		Adam6015Zero[6] = (float)0.0;

		Adam6015Type_Up[7] =		"  Pt392  ";
		Adam6015Type_Down[7] =	"  0~+200 ";
		Adam6015Span[7] = (float)200.0;
		Adam6015Zero[7] = (float)0.0;

		Adam6015Type_Up[8] =		"  Pt392  ";
		Adam6015Type_Down[8] =	"  0~+400";
		Adam6015Span[8] = (float)400.0;
		Adam6015Zero[8] = (float)0.0;
		
		Adam6015Type_Up[9] =		"  Pt392  ";
		Adam6015Type_Down[9] =	"-200~+200";
		Adam6015Span[9] = (float)200.0;
		Adam6015Zero[9] = (float)-200.0;
		
		Adam6015Type_Up[10] =		" Pt1000  ";
		Adam6015Type_Down[10] =	" -40~+160";
		Adam6015Span[10] = (float)160.0;
		Adam6015Zero[10] = (float)-40.0;

		Adam6015Type_Up[11] =   "  Balco  ";
		Adam6015Type_Down[11] =	" -30~+120";
		Adam6015Span[11] = (float)120.0;
		Adam6015Zero[11] = (float)-30.0;

		Adam6015Type_Up[12] =	"   NI    ";
		Adam6015Type_Down[12] = " -80~+100";
		Adam6015Span[12] = (float)100.0;
		Adam6015Zero[12] = (float)-80.0;

		Adam6015Type_Up[13] =	"   NI    ";
		Adam6015Type_Down[13] = " 0~+100  ";
		Adam6015Span[13] = (float)100.0;
		Adam6015Zero[13] = (float)0.0;

		for (i = 0; i < 9; i++)
		{
			ModBusRTU[0] = '$';
			ModBusRTU[1] = '0';
			ModBusRTU[2] = '1';
			ModBusRTU[3] = 'B';
			ModBusRTU[4] = '0';
			ModBusRTU[5] = (byte)(0x30 + i);
			ModBusRTU[6] = 0x0d;

			//System.out.println("send ADAM:" + ASC2HEX(ModBusRTU[5]));

			if (Adam6015Connection.Adam5kASCCmd(ModBusRTU, 7)) 
			{	
				try 
				{		
					//Remove mark by Tim.Lin
					//if (ModBusRTU[0] == '?')
					if (ModBusRTU[0] == '?' || (i==8 && ModBusRTU[0] == '!' && ModBusRTU[3] == 'F' && ModBusRTU[4] == 'F'))	//Modify Tim.Lin
					{
						Adam6015EachChannelType[i] = (-1);
						//labTypeAIAvg.setText("[Disable]");
						labTypeAIAvg_Up.setText("[Disable]");
						labTypeAIAvg_Down.setText("");
						continue;
					}

					tmp = (ASC2HEX(ModBusRTU[3]) << 4) + ASC2HEX(ModBusRTU[4]);
					tmp -= 0x20;
					//System.out.println("i=" + i + ", tmp: " + tmp);
					if (tmp <= 13)
					{											
						Adam6015EachChannelType[i] = tmp;
						//System.out.println("ADAMtype: " + Adam6015EachChannelType[i]);

						if (i == 0)
						{
							labTypeAI0_Up.setText(Adam6015Type_Up[tmp]);
							labTypeAI0_Down.setText(Adam6015Type_Down[tmp]);
						}	
						else if (i == 1)
						{
							labTypeAI1_Up.setText(Adam6015Type_Up[tmp]);
							labTypeAI1_Down.setText(Adam6015Type_Down[tmp]);
						}	
						else if (i == 2)
						{
							labTypeAI2_Up.setText(Adam6015Type_Up[tmp]);
							labTypeAI2_Down.setText(Adam6015Type_Down[tmp]);
						}
						else if (i == 3)
						{
							labTypeAI3_Up.setText(Adam6015Type_Up[tmp]);
							labTypeAI3_Down.setText(Adam6015Type_Down[tmp]);
						}
						else if (i == 4)
						{
							labTypeAI4_Up.setText(Adam6015Type_Up[tmp]);
							labTypeAI4_Down.setText(Adam6015Type_Down[tmp]);
						}
						else if (i == 5)
						{
							labTypeAI5_Up.setText(Adam6015Type_Up[tmp]);
							labTypeAI5_Down.setText(Adam6015Type_Down[tmp]);
						}
						else if (i == 6)
						{
							labTypeAI6_Up.setText(Adam6015Type_Up[tmp]);
							labTypeAI6_Down.setText(Adam6015Type_Down[tmp]);
						}/*
						else if (i == 7)
						{
							labTypeAI7_Up.setText(Adam6015Type_Up[tmp]);
							labTypeAI7_Down.setText(Adam6015Type_Down[tmp]);
						}*/					
						else if (i == 8)
						{
							labTypeAIAvg_Up.setText(Adam6015Type_Up[tmp]);
							labTypeAIAvg_Down.setText(Adam6015Type_Down[tmp]);
						}
						
						//labAdamStatusForDIO.setText("Adam status : Communcation successful (^_^)~" + "     Counter = " + ErrCnt++);
					}
				}
				catch(Exception e) {e.printStackTrace();}
			}
			else 
			{
				//labAdamStatusForDIO.setText("Adam status : Communcation timeout (^\"^)!!" + "     Counter = " + ErrCnt++);
				try 
				{
					//TCPInit();
					Adam6015Connection = new ModBus(HostIP);
				}	
				catch(Exception e) {	e.printStackTrace();	}
			}
		}

  }

  public void InitUserDefineScale() {
	 int i;
	 String SpanVal, OffVal;
		
		for (i = 0; i < 9; i++)
		{
			SpanVal = getParameter("SpanScaleValueCh" + String.valueOf(i));	
			OffVal = getParameter("OffsetScaleValueCh0" + String.valueOf(i));	
			//Adam6015_UserDefineSpanVal[i] = Float.parseFloat(SpanVal);
			//Adam6015_UserDefineZeroVal[i] = Float.parseFloat(OffVal);
			Adam6015_UserDefineSpanVal[i] = SpanVal;
			Adam6015_UserDefineZeroVal[i] = OffVal;
			//System.out.println("SpanVal :" + SpanVal);
			//System.out.println("OffVal :" + OffVal);
			/*
			if (Adam6015_UserDefineSpanVal[i] < Adam6015_UserDefineZeroVal[i])
			{
				//Adam6015_UserDefineSpanVal[i] = (float)100.0;
				//Adam6015_UserDefineZeroVal[i] = (float)0.0;
			}*/

		}
		
		
  }
  /**Construct the applet*/
  public Adam6015() {
  }
  /**Initialize the applet*/
  public void init() {
    try {
		HostIP  = getParameter("HostIP");
		Adam6015Connection = new ModBus(HostIP);
		InitAdam6015StartValue();
		if (HostIP == "")
			labAdamStatusForDIO.setText("Get Host IP is null !!");
		else
			labAdamStatusForDIO.setText("Get Host IP :" + Adam6015Connection.GetHostIP() + " Ver 1.20");
	
		//InitUserDefineScale();		
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    try {
      SetDIStatus(0) ;
		jbInit();
      AdamPoilThread = new Thread(this);
      AdamPoilThread.start();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }   
/*
  public void FillingAdam6015Type (Object p, String Msg)throws 
	  Exception{
	  //p.setText(Msg);
	  return;
  }
*/

/*  
 public void txtAIChValue(Object obj)
 {
	if (obj.equals("txtAICh0Value"))
	{
		txtAICh0Value.setText("Adam.Lin");
	}
	else
		txtAICh0Value.setText("FAIL");
	
	//return(super.action(evt, obj));
 }*/


  public void run() {
    boolean ErrCnt;
    String sRet;
	 String AIVal;
	
    ErrCnt = false;
	 
    while (true) {
      int i, tmp;
      byte ModBusRTU[] = new byte[128];
      
	  palMessageWindow.repaint();
      
      if (IsAdamDOoutRuning || !IsPWLogin)
        continue;
		
		IsAdamRuning = true;

		if (Adam6015Connection.ReadCoil( 0, 32, ModBusRTU)) {
        DisplayDIStatus(ModBusRTU);
        labAdamStatusForDIO.setText("Status : Communcation successful.");// (^_^)~" + "  Counter = " + ErrCnt++);
		  CommLed.setLed(ErrCnt);
		  if (ErrCnt)	ErrCnt = false;
		  else ErrCnt = true;
      }
		else 
		{
			labAdamStatusForDIO.setText("Status : Communcation timeout!!");// (^\"^)!!" + "  Counter = " + ErrCnt++);
		   CommLed.setLed(false);
			try 
			{
				//TCPInit();
				Adam6015Connection = new ModBus(HostIP);			
				InitAdam6015StartValue();
			}	catch(Exception e) {	e.printStackTrace(); }
		}

		
		//if (ChkIsHex.getState())	{	
			if (Adam6015Connection.ReadRegister( 0, 30, ModBusRTU)) {
				//String AIVal;
				float fTmp;
				long lTmp;
				String sTmp;

				//for (i = 0; i < 7; i++)
				for (i = 0; i < 9; i++)		//Tim.Lin modify
				{
					try
					{
						if (Adam6015EachChannelType[i] == (-1))
						{
							AIVal = "Null";
						}
						else
						{			
							if (ChkIsHex.getState())
							{	
								AIVal = "0x" + ConvertStrToHex((int)(ModBusRTU[9 + i *2])) + 
										ConvertStrToHex((int)ModBusRTU[10 + i *2]);
							}
							else if (ChkIsUserDefine.getState())
							{
								AIVal = /*Float.toString(*/Adam6015_UserDefineSpanVal[i];//);	
							}
							else
							{			
								AIVal = ConvertStrToHex((int)(ModBusRTU[9 + i *2])) + 
										ConvertStrToHex((int)ModBusRTU[10 + i *2]);
								lTmp = Long.parseLong(AIVal, 16);
								fTmp = (float)lTmp;							
								//System.out.println("Ch" + i + "Row Data: " + lTmp);
								fTmp = (Adam6015Span[Adam6015EachChannelType[i]] - Adam6015Zero[Adam6015EachChannelType[i]]) 
											/ 65535 * fTmp + Adam6015Zero[Adam6015EachChannelType[i]];											
	
								//AIVal = String.valueOf(fTmp);	//Tim.Lin Modify
								DecimalFormat   df   =   new   DecimalFormat();   
								AIVal=df.format(fTmp);
								
								if (AIVal.length() > 7)
								{
									AIVal = AIVal.substring(0, 7);
								}
							}						
						}			
						if (i == 0)
							txtAICh0Value.setText(AIVal);
						else if (i == 1)  
							txtAICh1Value.setText(AIVal);
						else if (i == 2)
							txtAICh2Value.setText(AIVal);
						else if (i == 3)
							txtAICh3Value.setText(AIVal);
						else if (i == 4)
							txtAICh4Value.setText(AIVal);
						else if (i == 5)
							txtAICh5Value.setText(AIVal);
						else if (i == 6)
							txtAICh6Value.setText(AIVal);
						else if (i == 8)
							txtAIAvgValue.setText(AIVal);				
					}
					catch(Exception e) {e.printStackTrace();}
				}
				
				for (i = 0; i < 9; i++)
				{	
					try
					{
						if (Adam6015EachChannelType[i] == (-1))
						{
							AIVal = "Null";
						}
						else
						{			
							if (ChkIsHex.getState())
							{	
								AIVal = "0x" + ConvertStrToHex((int)(ModBusRTU[29 + i *2])) + 
										ConvertStrToHex((int)ModBusRTU[30 + i *2]);
							}
							else
							{							
								
								AIVal = ConvertStrToHex((int)(ModBusRTU[29 + i *2])) + 
										ConvertStrToHex((int)ModBusRTU[30 + i *2]);
								lTmp = Long.parseLong(AIVal, 16);
								fTmp = (float)lTmp;							
								//System.out.println("Ch" + i + "Min Row Data: " + lTmp);
								fTmp = (Adam6015Span[Adam6015EachChannelType[i]] - Adam6015Zero[Adam6015EachChannelType[i]]) 
											/ 65535 * fTmp + Adam6015Zero[Adam6015EachChannelType[i]];			
								
				                //AIVal = String.valueOf(fTmp);	//Tim.Lin Modify
								DecimalFormat   df   =   new   DecimalFormat();   
								AIVal=df.format(fTmp);	
								
								if (AIVal.length() > 7)
								{
									AIVal = AIVal.substring(0, 7);
								}	
							}						
						}			
						if (i == 0)
							txtAIMaxCh0Value.setText(AIVal);
						else if (i == 1)  
							txtAIMaxCh1Value.setText(AIVal);
						else if (i == 2)
							txtAIMaxCh2Value.setText(AIVal);
						else if (i == 3)
							txtAIMaxCh3Value.setText(AIVal);
						else if (i == 4)
							txtAIMaxCh4Value.setText(AIVal);
						else if (i == 5)
							txtAIMaxCh5Value.setText(AIVal);
						else if (i == 6)
							txtAIMaxCh6Value.setText(AIVal);
						else if (i == 8)
							txtAIMaxAvgValue.setText(AIVal);				
					}
					catch(Exception e) {e.printStackTrace();}			
				}
				
				for (i = 0; i < 9; i++)
				{					
					try
					{
						if (Adam6015EachChannelType[i] == (-1))
						{
							AIVal = "Null";
						}
						else
						{			
							if (ChkIsHex.getState())
							{	
								AIVal = "0x" + ConvertStrToHex((int)(ModBusRTU[49 + i *2])) + 
										ConvertStrToHex((int)ModBusRTU[50 + i *2]);
							}
							else
							{							
								
								AIVal = ConvertStrToHex((int)(ModBusRTU[49 + i *2])) + 
										ConvertStrToHex((int)ModBusRTU[50 + i *2]);
								lTmp = Long.parseLong(AIVal, 16);
								fTmp = (float)lTmp;							
								//System.out.println("Ch" + i + "Min Row Data: " + lTmp);
								fTmp = (Adam6015Span[Adam6015EachChannelType[i]] - Adam6015Zero[Adam6015EachChannelType[i]]) 
											/ 65535 * fTmp + Adam6015Zero[Adam6015EachChannelType[i]];			

				                //AIVal = String.valueOf(fTmp);	//Tim.Lin Modify
								DecimalFormat   df   =   new   DecimalFormat();   
								AIVal=df.format(fTmp);
					
								if (AIVal.length() > 7)
								{
									AIVal = AIVal.substring(0, 7);
								}	
							}						
						}			
						if (i == 0)
							txtAIMinCh0Value.setText(AIVal);
						else if (i == 1)  
							txtAIMinCh1Value.setText(AIVal);
						else if (i == 2)
							txtAIMinCh2Value.setText(AIVal);
						else if (i == 3)
							txtAIMinCh3Value.setText(AIVal);
						else if (i == 4)
							txtAIMinCh4Value.setText(AIVal);
						else if (i == 5)
							txtAIMinCh5Value.setText(AIVal);
						else if (i == 6)
							txtAIMinCh6Value.setText(AIVal);
						else if (i == 8)
							txtAIMinAvgValue.setText(AIVal);				
					}
					catch(Exception e) {e.printStackTrace();}		
				}
				labAdamStatusForDIO.setText("Status : Communcation successful.");// (^_^)~" + "  Counter = " + ErrCnt++);
				CommLed.setLed(ErrCnt);
			}
	      else {
				labAdamStatusForDIO.setText("Status : Communcation timeout!!");// (^\"^)!!" + "  Counter = " + ErrCnt++);
				CommLed.setLed(false);
				try {
					//TCPInit();
					Adam6015Connection = new ModBus(HostIP);
					InitAdam6015StartValue();
				}	catch(Exception e) {
						e.printStackTrace();
				}
			}
		//}
		
	  IsAdamRuning = false;
     AdamDelay(1000);
    }
  }

 public void start() { }

 public void stop() { }

 public void destroy() {
	//Adam6015Connection.Close();
	AdamPoilThread	.stop();
	AdamPoilThread = null;
 }

  /**Component initialization*/

  private void jbInit() throws Exception {
    int PW_X = 150 , PW_Y = 80;

	 this.setLayout(null); 
	 palMessageWindow.setLayout(null); 
 	 //palMessageWindow.setBackground(Color.lightGray);
	 palMessageWindow.setBounds(new Rectangle(PW_X + 12, PW_Y + 15 , 320, 90));
	 LabMessage.setFont(new java.awt.Font("DialogInput", 3, 14));

	 LabMessage.setBounds(new Rectangle(18, 17, 220, 30));
	 txtUserPassword.setBounds(new Rectangle(240, 22, 60, 20));	
	 btPW_Apply.setBounds(new Rectangle(130, 22 + 30, 59, 25));
	 txtUserPassword.setForeground(Color.darkGray);
	 txtUserPassword.setBackground(Color.darkGray);	
		
	 palAIOStatus.add(palMessageWindow, null);
	 palMessageWindow.add(LabMessage, null);
	 palMessageWindow.add(txtUserPassword, null);
	 palMessageWindow.add(btPW_Apply, null);
	 palDO.disable();

	 btDO0.setForeground(Color.darkGray);
	 btDO1.setForeground(Color.darkGray);

    //palAIOStatus.setBackground(Color.lightGray);	 
    palAIOStatus.setBounds(new Rectangle(42, 47, 409 + 220, 7 + 7 + 125 + 90 + 33 + 13 + 20));//369 + 33));
    palAIOStatus.setLayout(null);

    palAI.setBounds(new Rectangle(12, 7 + 7 , 385 + 220, 125 + 90 + 20));
    palAI.setLayout(null);
	 
//    palDO.setLayout(null);
 //   palDO.setBounds(new Rectangle(12, 7 + 7 + 125 + 90 + 20, 385 + 220, 72));
	 
    //palAdamStatus.setBackground(Color.lightGray);
    palAdamStatus.setBounds(new Rectangle(14, 7 + 7 + 125 + 90 + 20, 381 + 220, 33));
    palAdamStatus.setLayout(null);

	 //palAdamStatus.setBackground(SystemColor.activeCaptionBorder);
    DIOLayout();
    JLabel1.setFont(new java.awt.Font("DialogInput", 3, 26));
    JLabel1.setForeground(Color.blue);
    JLabel1.setText("ADAM-6015 AI Module");
    JLabel1.setBounds(new Rectangle(83 + 123, 17, 326 + 123, 29));
    this.add(JLabel1, null);
    this.add(palAIOStatus, null);
	 //this.add(palAdamStatus, null);

    palAIOStatus.add(palAI, null);
    //palAIOStatus.add(palMaxAI, null);
    //palAIOStatus.add(palMinAI, null);
	 palAI.add(labAIAvg, null);	 
	 
	 palAI.add(txtAICh0Value, null);
	 palAI.add(txtAICh1Value, null);
	 palAI.add(txtAICh2Value, null);
	 palAI.add(txtAICh3Value, null);
	 palAI.add(txtAICh4Value, null);
	 palAI.add(txtAICh5Value, null);
	 palAI.add(txtAICh6Value, null);
	 
    txtAICh0Value.setEditable(false);
    txtAICh1Value.setEditable(false);
    txtAICh2Value.setEditable(false);
    txtAICh3Value.setEditable(false);
    txtAICh4Value.setEditable(false);
    txtAICh5Value.setEditable(false);
    txtAICh6Value.setEditable(false);

    palAI.add(labAI0, null);
    palAI.add(labAI1, null);
    palAI.add(labAI2, null);
    palAI.add(labAI3, null);
    palAI.add(labAI4, null);
    palAI.add(labAI5, null);
    palAI.add(labAI6, null);
	

	 palAI.add(txtAIAvgValue, null);
	 palAI.add(labAIAvg, null);
	 txtAIAvgValue.setEditable(false);
	
	 palAI.add(txtAIMaxCh0Value, null);
	 palAI.add(txtAIMaxCh1Value, null);
	 palAI.add(txtAIMaxCh2Value, null);
	 palAI.add(txtAIMaxCh3Value, null);
	 palAI.add(txtAIMaxCh4Value, null);
	 palAI.add(txtAIMaxCh5Value, null);
	 palAI.add(txtAIMaxCh6Value, null);

	 txtAIMaxCh0Value.setEditable(false);
	 txtAIMaxCh1Value.setEditable(false);
	 txtAIMaxCh2Value.setEditable(false);
	 txtAIMaxCh3Value.setEditable(false);
	 txtAIMaxCh4Value.setEditable(false);
	 txtAIMaxCh5Value.setEditable(false);
	 txtAIMaxCh6Value.setEditable(false);
	 
	 palAI.add(txtAIMaxAvgValue, null);
	 txtAIMaxAvgValue.setEditable(false);

    palAI.add(btRetMaxCh0, null);
    palAI.add(btRetMaxCh1, null);
    palAI.add(btRetMaxCh2, null);
    palAI.add(btRetMaxCh3, null);
    palAI.add(btRetMaxCh4, null);
    palAI.add(btRetMaxCh5, null);
    palAI.add(btRetMaxCh6, null);
    palAI.add(btRetMaxCh8, null);

    palAI.add(btRetMinCh0, null);
    palAI.add(btRetMinCh1, null);
    palAI.add(btRetMinCh2, null);
    palAI.add(btRetMinCh3, null);
    palAI.add(btRetMinCh4, null);
    palAI.add(btRetMinCh5, null);
    palAI.add(btRetMinCh6, null);
    palAI.add(btRetMinCh8, null);

	 palAI.add(txtAIMinCh0Value, null);
	 palAI.add(txtAIMinCh1Value, null);
	 palAI.add(txtAIMinCh2Value, null);
	 palAI.add(txtAIMinCh3Value, null);
	 palAI.add(txtAIMinCh4Value, null);
	 palAI.add(txtAIMinCh5Value, null);
	 palAI.add(txtAIMinCh6Value, null);
	 
	 palAI.add(ChkIsEng, null);
	 palAI.add(ChkIsHex, null);
	 //palAI.add(ChkIsUserDefine, null);

    palAI.add(labTypeAI0_Up, null);  
    palAI.add(labTypeAI1_Up, null);
    palAI.add(labTypeAI2_Up, null);
    palAI.add(labTypeAI3_Up, null);
    palAI.add(labTypeAI4_Up, null);
    palAI.add(labTypeAI5_Up, null);
    palAI.add(labTypeAI6_Up, null);
    palAI.add(labTypeAIAvg_Up, null);

    palAI.add(labTypeAI0_Down, null);  
    palAI.add(labTypeAI1_Down, null);
    palAI.add(labTypeAI2_Down, null);
    palAI.add(labTypeAI3_Down, null);
    palAI.add(labTypeAI4_Down, null);
    palAI.add(labTypeAI5_Down, null);
    palAI.add(labTypeAI6_Down, null);
    palAI.add(labTypeAIAvg_Down, null);
	 //palAI.add(cbg, null);

	 txtAIMinCh0Value.setEditable(false);
	 txtAIMinCh1Value.setEditable(false);
	 txtAIMinCh2Value.setEditable(false);
	 txtAIMinCh3Value.setEditable(false);
	 txtAIMinCh4Value.setEditable(false);
	 txtAIMinCh5Value.setEditable(false);
	 txtAIMinCh6Value.setEditable(false);
	 
	 palAI.add(labNormal, null);
    palAI.add(labMaximum, null);
    palAI.add(labMinimum, null);
    palAI.add(labResetMaximum, null);
    palAI.add(labResetMinimum, null);
	 palAI.add(txtAIMinAvgValue, null);

	 txtAIMinAvgValue.setEditable(false);

    //palAIOStatus.add(palDO, null);
    //palDO.add(LedDO0, null);
    //palDO.add(LedDO1, null);
    //palDO.add(btDO0, null);
    //palDO.add(btDO1, null);

    //palDO.add(txtDOLowByteValue, null);
    //palDO.add(labDOLowByteValue, null);
	 	
    palAIOStatus.add(palAdamStatus, null);	 
	 labAdamStatusForDIO.setBounds(new Rectangle(10, 8, 300, 12));
	 palAdamStatus.add(labAdamStatusForDIO, null);	 
	 palAdamStatus.add(CommLed, null);
	 CommLed.setBounds(new Rectangle(575, 7, 18, 18));
  }

	int ASC2HEX(byte c)
	{
		if (( c >='0')&&(c <='9'))
			return (int)(c -'0');
		if (( c >='A')&&(c <='F'))
   		return (int)(c -'A'+10);
		if (( c >='a')&&(c <='f'))
   		return (int)(c -'a'+10);
		else return 0;
	}

	void DIOLayout() {
    int x,  y, X_Spe, Y_Spe, Height, Weight;
    int X_Off, Y_Off;

    X_Off = 55; Y_Off = 5;
    x = 20 + X_Off; y = 15 + Y_Off; Height = 20; Weight = 50;
    X_Spe = 68; Y_Spe = 25;		
	 y -= 2;	 

    labAI0.setBounds(new Rectangle(x, y, Weight, Height));
    labAI1.setBounds(new Rectangle(x + X_Spe, y, Weight, Height));
    labAI2.setBounds(new Rectangle(x + X_Spe * 2, y, Weight, Height));
    labAI3.setBounds(new Rectangle(x + X_Spe * 3, y, Weight, Height));
    labAI4.setBounds(new Rectangle(x + X_Spe * 4, y, Weight, Height));
    labAI5.setBounds(new Rectangle(x + X_Spe * 5, y, Weight, Height));
    labAI6.setBounds(new Rectangle(x + X_Spe * 6, y, Weight, Height)); 
	 labAIAvg.setBounds(new Rectangle(x + X_Spe * 7, y, Weight, Height));
	 
	 y += 2;
	 y = y + 15;
	 x -= 13;
	 Weight += 10;
	 labTypeAI0_Up.setBounds(new Rectangle(x, y, Weight, Height));
	 labTypeAI1_Up.setBounds(new Rectangle(x + X_Spe, y, Weight, Height));
    labTypeAI2_Up.setBounds(new Rectangle(x + X_Spe * 2, y, Weight, Height));
    labTypeAI3_Up.setBounds(new Rectangle(x + X_Spe * 3, y, Weight, Height));
    labTypeAI4_Up.setBounds(new Rectangle(x + X_Spe * 4, y, Weight, Height));
    labTypeAI5_Up.setBounds(new Rectangle(x + X_Spe * 5, y, Weight, Height));
    labTypeAI6_Up.setBounds(new Rectangle(x + X_Spe * 6, y, Weight, Height));
	 labTypeAIAvg_Up.setBounds(new Rectangle(x + X_Spe * 7, y, Weight, Height));


	 y += 2;
	 y = y + 15;
	 x -= 8;
	 Weight += 10;
	 labTypeAI0_Down.setBounds(new Rectangle(x, y, Weight, Height));
	 labTypeAI1_Down.setBounds(new Rectangle(x + X_Spe, y, Weight, Height));
    labTypeAI2_Down.setBounds(new Rectangle(x + X_Spe * 2, y, Weight, Height));
    labTypeAI3_Down.setBounds(new Rectangle(x + X_Spe * 3, y, Weight, Height));
    labTypeAI4_Down.setBounds(new Rectangle(x + X_Spe * 4, y, Weight, Height));
    labTypeAI5_Down.setBounds(new Rectangle(x + X_Spe * 5, y, Weight, Height));
    labTypeAI6_Down.setBounds(new Rectangle(x + X_Spe * 6, y, Weight, Height));
	 labTypeAIAvg_Down.setBounds(new Rectangle(x + X_Spe * 7, y, Weight, Height));
	
	//x += 2;
	 x = 3 + X_Off; y += 16 + Y_Off; Height = 20; Weight = 56;
	 
	 /*
	 palAI.add(, null);
    palAI.add(, null);
    palAI.add(, null);
    palAI.add(labResetMaximum, null);
    palAI.add(labResetMinimum, null);
	 */
	 
    labNormal.setBounds(new Rectangle(x - 48, y, Weight, Height));
	 
    txtAICh0Value.setBounds(new Rectangle(x, y, Weight, Height));
    txtAICh1Value.setBounds(new Rectangle(x + X_Spe, y, Weight, Height));
    txtAICh2Value.setBounds(new Rectangle(x + X_Spe * 2, y, Weight, Height));
    txtAICh3Value.setBounds(new Rectangle(x + X_Spe * 3, y, Weight, Height));
    txtAICh4Value.setBounds(new Rectangle(x + X_Spe * 4, y, Weight, Height));
    txtAICh5Value.setBounds(new Rectangle(x + X_Spe * 5, y, Weight, Height));
    txtAICh6Value.setBounds(new Rectangle(x + X_Spe * 6, y, Weight, Height));
    txtAIAvgValue.setBounds(new Rectangle(x + X_Spe * 7, y, Weight, Height));

	 
    labMaximum.setBounds(new Rectangle(x - 48, y + Y_Spe, Weight, Height));	
	 txtAIMaxCh0Value.setBounds(new Rectangle(x, y + Y_Spe, Weight, Height));
    txtAIMaxCh1Value.setBounds(new Rectangle(x + X_Spe, y + Y_Spe, Weight, Height));
    txtAIMaxCh2Value.setBounds(new Rectangle(x + X_Spe * 2, y + Y_Spe, Weight, Height));
    txtAIMaxCh3Value.setBounds(new Rectangle(x + X_Spe * 3, y + Y_Spe, Weight, Height));
    txtAIMaxCh4Value.setBounds(new Rectangle(x + X_Spe * 4, y + Y_Spe, Weight, Height));
    txtAIMaxCh5Value.setBounds(new Rectangle(x + X_Spe * 5, y + Y_Spe, Weight, Height));
    txtAIMaxCh6Value.setBounds(new Rectangle(x + X_Spe * 6, y + Y_Spe, Weight, Height));
    txtAIMaxAvgValue.setBounds(new Rectangle(x + X_Spe * 7, y + Y_Spe, Weight, Height));  

	 //y = y - 15;
	 
    labResetMaximum.setBounds(new Rectangle(x - 48, y + Y_Spe * 2, Weight, Height));	
    btRetMaxCh0.setBounds(new Rectangle(x, y + Y_Spe * 2, Weight, Height));
    btRetMaxCh1.setBounds(new Rectangle(x + X_Spe, y + Y_Spe * 2, Weight, Height));
    btRetMaxCh2.setBounds(new Rectangle(x + X_Spe * 2, y + Y_Spe * 2, Weight, Height));
    btRetMaxCh3.setBounds(new Rectangle(x + X_Spe * 3, y + Y_Spe * 2, Weight, Height));
    btRetMaxCh4.setBounds(new Rectangle(x + X_Spe * 4, y + Y_Spe * 2, Weight, Height));
    btRetMaxCh5.setBounds(new Rectangle(x + X_Spe * 5, y + Y_Spe * 2, Weight, Height));
    btRetMaxCh6.setBounds(new Rectangle(x + X_Spe * 6, y + Y_Spe * 2, Weight, Height));
    btRetMaxCh8.setBounds(new Rectangle(x + X_Spe * 7, y + Y_Spe * 2, Weight, Height));  
		
	 
    labMinimum.setBounds(new Rectangle(x - 48, y + Y_Spe * 3, Weight, Height));	
    txtAIMinCh0Value.setBounds(new Rectangle(x, y + Y_Spe * 3, Weight, Height));
    txtAIMinCh1Value.setBounds(new Rectangle(x + X_Spe, y + Y_Spe * 3, Weight, Height));
    txtAIMinCh2Value.setBounds(new Rectangle(x + X_Spe * 2, y + Y_Spe * 3, Weight, Height));
    txtAIMinCh3Value.setBounds(new Rectangle(x + X_Spe * 3, y + Y_Spe * 3, Weight, Height));
    txtAIMinCh4Value.setBounds(new Rectangle(x + X_Spe * 4, y + Y_Spe * 3, Weight, Height));
    txtAIMinCh5Value.setBounds(new Rectangle(x + X_Spe * 5, y + Y_Spe * 3, Weight, Height));
    txtAIMinCh6Value.setBounds(new Rectangle(x + X_Spe * 6, y + Y_Spe * 3, Weight, Height));
    txtAIMinAvgValue.setBounds(new Rectangle(x + X_Spe * 7, y + Y_Spe * 3, Weight, Height));  
	 	 
	 //y = y - 15;
	 
    labResetMinimum.setBounds(new Rectangle(x - 48, y + Y_Spe * 4, Weight, Height));	
    btRetMinCh0.setBounds(new Rectangle(x, y + Y_Spe * 4, Weight, Height));
    btRetMinCh1.setBounds(new Rectangle(x + X_Spe, y + Y_Spe * 4, Weight, Height));
    btRetMinCh2.setBounds(new Rectangle(x + X_Spe * 2, y + Y_Spe * 4, Weight, Height));
    btRetMinCh3.setBounds(new Rectangle(x + X_Spe * 3, y + Y_Spe * 4, Weight, Height));
    btRetMinCh4.setBounds(new Rectangle(x + X_Spe * 4, y + Y_Spe * 4, Weight, Height));
    btRetMinCh5.setBounds(new Rectangle(x + X_Spe * 5, y + Y_Spe * 4, Weight, Height));
    btRetMinCh6.setBounds(new Rectangle(x + X_Spe * 6, y + Y_Spe * 4, Weight, Height));
    btRetMinCh8.setBounds(new Rectangle(x + X_Spe * 7, y + Y_Spe * 4, Weight, Height));  
	
    ChkIsEng.setBounds(new Rectangle(x, y + Y_Spe * 5, Weight, Height));
    ChkIsHex.setBounds(new Rectangle(x + X_Spe, y + Y_Spe * 5, Weight, Height));  
    ChkIsUserDefine.setBounds(new Rectangle(x + X_Spe * 2, y + Y_Spe * 5, Weight, Height));  
	
    x = 20 + X_Off; y = 25 + Y_Off; Height = 20; Weight = 20;
    X_Spe = 60; Y_Spe = 35;
	 x += 10;
    LedDO0.setBounds(new Rectangle(x, y, Weight, Height));
    btDO0.setBounds(new Rectangle(x + 25, y - 1, 50, 20));

	 x += 100;
    LedDO1.setBounds(new Rectangle(x, y, Weight, Height));
    btDO1.setBounds(new Rectangle(x + 25, y - 1, 50, 20));

	 //x = 20 + X_Off; y = 45 + Y_Off; Height = 25; Weight = 59;
    //X_Spe = 60; Y_Spe = 35;
    txtDOLowByteValue.setEditable(false);
    txtDOLowByteValue.setFont(new java.awt.Font("SansSerif", 1, 14));

	 x += 140;
    labDOLowByteValue.setBounds(new Rectangle(x, y, 100, 20));
	 txtDOLowByteValue.setBounds(new Rectangle(x + 105, y - 1, 80, 20));

    btDO0.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {
        //SendCmd2Adam("#010001", 2);
        if (PWIsCorrect)
          SetDOutput(0);
      }
    });
    btDO1.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {
		  //SendCmd2Adam("#010002", 2);
        if (PWIsCorrect)
		  SetDOutput(1);
      }
    });	

	 
    btRetMaxCh0.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {		
		  Adam6015Connection.ForceCoil(100, true);
		}
    });

    btRetMaxCh1.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {				
		  Adam6015Connection.ForceCoil(101, true);
      }
    });

    btRetMaxCh2.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {				
		  Adam6015Connection.ForceCoil(102, true);
      }
    });

    btRetMaxCh3.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {				
		  Adam6015Connection.ForceCoil(103, true);
      }
    });

    btRetMaxCh4.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {				
		  Adam6015Connection.ForceCoil(104, true);
      }
    });

    btRetMaxCh5.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {				
		  Adam6015Connection.ForceCoil(105, true);
      }
    });

    btRetMaxCh6.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {				
		  Adam6015Connection.ForceCoil(106, true);
      }
    });

    btRetMaxCh8.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {				
		  Adam6015Connection.ForceCoil(108, true);
      }
    });
	 	 
    btRetMinCh0.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {		
		  Adam6015Connection.ForceCoil(110, true);
		}
    });

    btRetMinCh1.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {				
		  Adam6015Connection.ForceCoil(111, true);
      }
    });

    btRetMinCh2.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {				
		  Adam6015Connection.ForceCoil(112, true);
      }
    });

    btRetMinCh3.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {				
		  Adam6015Connection.ForceCoil(113, true);
      }
    });

    btRetMinCh4.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {				
		  Adam6015Connection.ForceCoil(114, true);
      }
    });

    btRetMinCh5.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {				
		  Adam6015Connection.ForceCoil(115, true);
      }
    });

    btRetMinCh6.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {				
		  Adam6015Connection.ForceCoil(116, true);
      }
    });

    btRetMinCh8.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(MouseEvent e) {				
		  Adam6015Connection.ForceCoil(117, true);
      }
    });

	 btPW_Apply.addMouseListener(new java.awt.event.MouseAdapter() {	//2002/8/27
    public void mousePressed(MouseEvent e) {
		UserPassWordArray = txtUserPassword.getText().getBytes();
		if (ChkPW(UserPassWordArray, txtUserPassword.getText().length()) && txtUserPassword.getText().length() > 0)
		{	
			//txtUserPassword.setText("PASS");
			//palDI.enable();			
			palDO.SetTitleMsg(" Adam DO Status(Operating Mode) ", 190);
			palDO.enable();			
			btDO0.setForeground(Color.black);
			btDO1.setForeground(Color.black);
			palMessageWindow.setVisible(false);		
            PWIsCorrect = true;	
            IsPWLogin  = true;	
      	    palDO.repaint();  			
		}
		else 
		{			
			palDO.SetTitleMsg(" Adam DO Status(Monitoring Mode) ", 200);
			palMessageWindow.setVisible(false);	
			//txtUserPassword.setText("FAIL");
            PWIsCorrect = false;	
            IsPWLogin  = true;	
      	    palDO.repaint();  
		}
     }
    });
  }

  /**Get Applet information*/
  public String getAppletInfo() {
    return "Applet Information";
  }
  /**Get parameter info*/
  public String[][] getParameterInfo() {
    String[][] pinfo =
      {
      {"HostIP", "String", ""},
      };
    return pinfo;
  }



  public String ConvertStrToHex(int Data) {
      String tmp;
      tmp = Long.toHexString((int)Data);
      if (tmp.length() > 2)
        tmp = tmp.substring(tmp.length() - 2);
        if (tmp.length() == 1)
          tmp = "0" + tmp;
        return tmp.toUpperCase();
      }

  void SetDOutput(int Ch)  {
      long lData;
		boolean IsTrunOn;
		byte ModBusRTU[] = new byte[128];

		if (IsAdamRuning) return;

		IsAdamDOoutRuning = true;
      AdamPoilThread.suspend();
		
      lData = (GetDIStatus() >> 16);
      if ( (lData & (0x1 << Ch)) > 0) {
         IsTrunOn = false;
      }
      else {
         IsTrunOn = true;
      }

		if(Adam6015Connection.ForceCoil(16 + Ch, IsTrunOn)) {
			if (Adam6015Connection.ReadCoil( 0, 32, ModBusRTU))
				DisplayDIStatus(ModBusRTU);
			else {
				Adam6015Connection = new ModBus(HostIP);
			}
      }
      else {
		  Adam6015Connection = new ModBus(HostIP);
      }

      AdamPoilThread.resume();		
		IsAdamDOoutRuning = false;
  }


  long DIO_Status;

  long GetDIStatus()  {
    return DIO_Status;
  }

  void SetDIStatus(long lData)  {
    DIO_Status = lData;
  }

  boolean Is1stDIStatusUpdate = true;

   void DisplayDIStatus(byte ModBusRTU[]) {
    byte DI_Hi_Byte, DI_Low_Byte;
    byte DO_Low_Byte;
    long Data;

	 Data = (long)(ModBusRTU[9] & 0xff);
	 Data |= (long)((ModBusRTU[10] & 0xff) << 8);
    Data |= (long)((ModBusRTU[11] & 0x3F) << 16);


    DI_Low_Byte = (byte)(Data & 0x0FF);
    DI_Hi_Byte = (byte)((Data & 0xF00) >> 8);
    DO_Low_Byte = (byte)((Data & 0x3F0000) >> 16);
	 txtDOLowByteValue.setText("0x" + ConvertStrToHex((int)DO_Low_Byte));

	 
	 if (Data == GetDIStatus())
		return;
	
	 if (DO_Low_Byte != (byte)((GetDIStatus() & 0x3F0000) >> 16)) {
		if((DO_Low_Byte & 0x1) >= 1)
			LedDO0.setLed(true);
		else  LedDO0.setLed(false);

		if((DO_Low_Byte & 0x2) >= 1)
			LedDO1.setLed(true);
		else  LedDO1.setLed(false);
	 }

    SetDIStatus(Data) ;
  }

  void AdamDelay(int DT) {
    try  {
      Thread.sleep(DT);
    }  catch(Exception eSleep)  {}
  }

  void EncodePassWord(byte PassWord[])
  {
	int i;
	
	for ( i = 0; i < 8; i++ )
	{
		//try {
			PassWord[i + 6] ^= 0x3f;
		//}
		//catch(Exception e) {
		//	PassWord[i] = 0x30;
		//}		
	}

	return;
  }; 
  
  public boolean ChkPW(byte PassWord[], int Len)
  { 
	int i;
   byte ModBusRTU[] = new byte[128];
	//char SystemPassWord[10];
	//System.out.println("ChkPW:" + Len);
	ModBusRTU[0] = '$';
	ModBusRTU[1] = '0';
	ModBusRTU[2] = '1';
	ModBusRTU[3] = 'P';
	ModBusRTU[4] = 'W';
	ModBusRTU[5] = '0';
	/*	
	if (Len < 8)
	{
		for (i = 0; i < (8 - Len + i); i++)
		{
			PassWord[8 - Len + i] = 0x30;	
		}
	}*/	

	for (i = 0; i < 8; i++)
	{
		try
		{
			ModBusRTU[6 + i] = PassWord[i];	
		}
		catch(Exception e) {
			ModBusRTU[6 + i] = 0x31;
		}
		//System.out.println("ModBusRTU[" + i +"] = " + ModBusRTU[6 + i]);
	}	
	ModBusRTU[6 + i] = 0x0d;	

	EncodePassWord(ModBusRTU);

	//System.out.println("send ADAM:" + ASC2HEX(ModBusRTU[5]));

	if (Adam6015Connection.Adam5kASCCmd(ModBusRTU, 15)) 
	{
		try 
		{			
			if (ModBusRTU[0] == '!' && ModBusRTU[1] == '0' && ModBusRTU[2] == '1')
				return true;
			else return false;
		}
		catch(Exception e) {e.printStackTrace();}
	}
	
	return true;
  };
  /**Main method*/
  public static void main(String[] args) {
    Adam6015 applet = new Adam6015();
    applet.isStandalone = true;
    Frame frame;
    frame = new Frame() {
      protected void processWindowEvent(WindowEvent e) {
        super.processWindowEvent(e);
        if (e.getID() == WindowEvent.WINDOW_CLOSING) {
          System.exit(0);
        }
      }
      public synchronized void setTitle(String title) {
        super.setTitle(title);
        enableEvents(AWTEvent.WINDOW_EVENT_MASK);
      }
    };
    frame.setTitle("Applet Frame");
    frame.add(applet, BorderLayout.CENTER);
    applet.init();
    applet.start();
    frame.setSize(500 + 200,620);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
    frame.setVisible(true);
  }

}


class ModBus extends Object
{
	static InetAddress target;
	Socket echoSocket = null;
	DataOutputStream out = null;
	DataInputStream in = null;
	String myHost;
	byte ModBusRTUCmd[] = new byte[128];
	byte ModBusID;
	static boolean IsRuning = false;

	public ModBus(String Host, int ID) {
		if (IsRuning)	Close();
		IsRuning = true;

		myHost = chkHostIP(Host);
		//myHost = Host;
      ModBusID = (byte)ID;
      try {
         TCPInit();
      } catch(Exception e) {
         e.printStackTrace();
      }
	}
		
	public boolean IsModBusAlive() {
		return IsRuning;
	}

	public ModBus(String Host) {
		if (IsRuning)	Close();
		IsRuning = true;

		//myHost = Host;
		myHost = chkHostIP(Host);
      ModBusID = 0x01;
      try {
         TCPInit();
      } catch(Exception e) {
         e.printStackTrace();
      }
	}
	
	public String GetHostIP() {
		return myHost;
	}

	public void TCPInit() throws Exception {
		try {
			echoSocket = new Socket(myHost, 502);
			echoSocket.setSoTimeout(10000);
			out = new DataOutputStream(echoSocket.getOutputStream());
			in = new DataInputStream(echoSocket.getInputStream());

			} catch (UnknownHostException e) {
				System.err.println("Don't know about host: taranis.");
				System.exit(1);
		} catch (IOException e) {
				System.err.println("Couldn't get I/O for "
                               + "the connection to: taranis.");
				System.exit(1);
		}
  }

  public boolean ForceCoil(int CoilAddr, boolean IsTrunOn) {
		ModBusRTUCmd[0] = 0; ModBusRTUCmd[1] = 0; ModBusRTUCmd[2] = 0;
		ModBusRTUCmd[3] = 0; ModBusRTUCmd[4] = 0; ModBusRTUCmd[5] = 6;
		ModBusRTUCmd[6] = ModBusID;
		ModBusRTUCmd[7] = 0x05;			//ModBUsFunction code
		ModBusRTUCmd[8] = 0x0;
		ModBusRTUCmd[9] = (byte)CoilAddr;

		if (IsTrunOn)	{
			ModBusRTUCmd[10] = (-1);
		}
		else {
			ModBusRTUCmd[10] = 0;
		}
		ModBusRTUCmd[11] = 0;

		return SendCmd2Adam(ModBusRTUCmd, 12);
  }

  public boolean ReadCoil(int SatrtingAddr, int NoOfPoint, byte ModBusRTU[]) {
		ModBusRTUCmd[0] = 0; ModBusRTUCmd[1] = 0; ModBusRTUCmd[2] = 0;
		ModBusRTUCmd[3] = 0; ModBusRTUCmd[4] = 0; ModBusRTUCmd[5] = 6;
		ModBusRTUCmd[6] = ModBusID;
		ModBusRTUCmd[7] = 0x01;			//ModBUsFunction code
		ModBusRTUCmd[8] = 0x0;
		ModBusRTUCmd[9] = (byte)SatrtingAddr;
		ModBusRTUCmd[10] = 0x0;
		ModBusRTUCmd[11] = (byte)NoOfPoint;

		return SendCmd2Adam(ModBusRTU, 12);
  }

  public boolean PresetRegister(int RegAddr, int Data) {
		ModBusRTUCmd[0] = 0; ModBusRTUCmd[1] = 0; ModBusRTUCmd[2] = 0;
		ModBusRTUCmd[3] = 0; ModBusRTUCmd[4] = 0; ModBusRTUCmd[5] = 6;
		ModBusRTUCmd[6] = ModBusID;
		ModBusRTUCmd[7] = 0x06;			//ModBUsFunction code
		ModBusRTUCmd[8] = 0x0;
		ModBusRTUCmd[9] = (byte)RegAddr;
		ModBusRTUCmd[10] = (byte)((Data & 0xFF) >> 8);
		ModBusRTUCmd[11] = (byte)(Data & 0xFF);

		return SendCmd2Adam(ModBusRTUCmd, 12);
  }

  public boolean ReadRegister(int SatrtingAddr, int NoOfPoint, byte ModBusRTU[]) {
		ModBusRTUCmd[0] = 0; ModBusRTUCmd[1] = 0; ModBusRTUCmd[2] = 0;
		ModBusRTUCmd[3] = 0; ModBusRTUCmd[4] = 0; ModBusRTUCmd[5] = 6;
		ModBusRTUCmd[6] = ModBusID;
		ModBusRTUCmd[7] = 0x03;			//ModBUsFunction code
		ModBusRTUCmd[8] = 0x0;
		ModBusRTUCmd[9] = (byte)SatrtingAddr;
		ModBusRTUCmd[10] = 0x0;
		ModBusRTUCmd[11] = (byte)NoOfPoint;

		return SendCmd2Adam(ModBusRTU, 12);
  }

  public boolean Adam5kASCCmd(byte ModBusRTU[], int len) {
		int i, j;
		long l, m;
		String Echo;
	  
		ModBusRTUCmd[0] = 0; ModBusRTUCmd[1] = 0; ModBusRTUCmd[2] = 0;
		ModBusRTUCmd[3] = 0; ModBusRTUCmd[4] = 0; 

		ModBusRTUCmd[6] = ModBusID;
		ModBusRTUCmd[7] = 0x10;                   //Function Code
		ModBusRTUCmd[8] = ((9999 & 0xFF00) >> 8);
		ModBusRTUCmd[9] = (9999 & 0xFF);//(byte)SatrtingAddr;
		
		
		//len = ASCCmd.length() + 1;
	   //if ( len == 0 ) len++;
		if ( (len % 2) == 1 )
	   {
		//	ASCCmd.Substring()
		//   ASCCmd.indexOf(ASCCmd.length()) = 0x0;
			++len;
	   }

		
		ModBusRTUCmd[5] = (byte)(7 + len); 

		ModBusRTUCmd[10] = 0x00;                   //No. of Register Hi
	   ModBusRTUCmd[11] = (byte)((len / 2)); //No. of Register Low
	   ModBusRTUCmd[12] = (byte)len;              //Byte Counter
		/*
		for ( i = 0; i < (len - 1); i++ )
			ModBusRTUCmd[13 + i] = (byte)ASCCmd.indexOf(i);
			*/
		for (i = 0; i < len; i++)
		{
			ModBusRTUCmd[13 + i] = ModBusRTU[i];
		}

		//return SendCmd2Adam(ModBusRTUCmd, 13 + len);
		
		if (!SendCmd2Adam(ModBusRTUCmd, 13 + len))
		{
			return false;
		}
		
/*
		for (l = 0; l < 9999; l++)
		{
			for (m = 0; m < 9999; m++);
		}*/
		
		ModBusRTUCmd[0] = 0; ModBusRTUCmd[1] = 0; ModBusRTUCmd[2] = 0;
		ModBusRTUCmd[3] = 0; ModBusRTUCmd[4] = 0; ModBusRTUCmd[5] = 6;
		ModBusRTUCmd[6] = ModBusID;
		ModBusRTUCmd[7] = 0x03;			//ModBUsFunction code
		ModBusRTUCmd[8] = ((9999 & 0xFF00) >> 8);
		ModBusRTUCmd[9] = (9999 & 0xFF);//(byte)SatrtingAddr;
		ModBusRTUCmd[10] = 0x0;
		ModBusRTUCmd[11] = 50;//(byte)NoOfPoint;

		if (SendCmd2Adam(ModBusRTUCmd, 12))
		{
			for (i = 0; i < 100; i++)
			{
				ModBusRTU[i] = ModBusRTUCmd[9 + i];
				if (ModBusRTU[i] == 0x0d)
					return true;
			}
			return true;
		}
		else	return false;
		
  }
/*
	public boolean ReadAdam5kASCCmd(byte ModBusRTU[]) {
		int i, j;
		String Echo;

		ModBusRTUCmd[0] = 0; ModBusRTUCmd[1] = 0; ModBusRTUCmd[2] = 0;
		ModBusRTUCmd[3] = 0; ModBusRTUCmd[4] = 0; ModBusRTUCmd[5] = 6;
		ModBusRTUCmd[6] = ModBusID;
		ModBusRTUCmd[7] = 0x03;			//ModBUsFunction code
		ModBusRTUCmd[8] = ((9999 & 0xFF00) >> 8);
		ModBusRTUCmd[9] = (9999 & 0xFF);//(byte)SatrtingAddr;
		ModBusRTUCmd[10] = 0x0;
		ModBusRTUCmd[11] = 20;//(byte)NoOfPoint;

		if (SendCmd2Adam(ModBusRTUCmd, 12))
		{
			for (i = 0; i < 20; i++)
			{
				ModBusRTU[i] = ModBusRTUCmd[9 + i];
				if (ModBusRTU[i] == 0x0d)
					return true;
			}
			return true;
		}
		else	return false;
		
  }
*/
  private void Close() {
	  try {	  	
			echoSocket.close();
			out.close();
			in.close();
	  }
	  catch (IOException e) {
			IsRuning = false;
	  }
  }

  private	String chkHostIP(String Host) {
	  String tmp = "";

	  if (Host.length() < 15)	return Host;

	  for (int i = 0; i < 16; i += 4) {
			tmp += (String.valueOf(Long.valueOf(Host.substring(i, i + 3), 16)) + '.');
	  }
	  
	  return tmp.substring(0, tmp.length() - 1);
  }

  private boolean SendCmd2Adam(byte ModBusRTU[], int CmdLen) {
      int RetLen, i;
      try
		{
         out.write(ModBusRTUCmd, 0, CmdLen);
         RetLen = in.read(ModBusRTU, 0, 128);
         if (RetLen <= 0) return false;
      }
      catch (IOException e) {	return false;	}
      return true;
  }

}


class myFramPanel extends JPanel
{
  int panelType;
  Border BrdStyle;
  TitledBorder myTitledBorder;
  //JLabel labMassage = new JLabel("");

  public myFramPanel() {
    super();
    BrdStyle = new EtchedBorder(EtchedBorder.RAISED, Color.white,
                                new Color(134, 134, 134));
    myTitledBorder = new TitledBorder(BrdStyle);
    this.setBorder(myTitledBorder);
    this.repaint();
  }

  public myFramPanel(int myType) {
    super();
    //panelType = myType;
    BrdStyle = new EtchedBorder(EtchedBorder.RAISED, Color.white,
                                new Color(134, 134, 134));
    myTitledBorder = new TitledBorder(BrdStyle);
    this.setBorder(myTitledBorder);
    this.repaint();
  }

  public myFramPanel(int myType, String Msg, int msgTextLength) {
    super();
    BrdStyle = new EtchedBorder(EtchedBorder.RAISED, Color.white,
                                new Color(134, 134, 134));
    myTitledBorder = new TitledBorder(BrdStyle, Msg);
    this.setBorder(myTitledBorder);
    this.repaint();
    /*
       panelType = myType;
       if (Msg != "") {
     labMassage.setText(Msg);
     this.setLayout(null);
     labMassage.setBounds(new Rectangle(20, 3, msgTextLength, 15));
     this.add(labMassage);
       }*/
  }

  public void SetTitleMsg(String Msg, int msgTextLength) {    
    BrdStyle = new EtchedBorder(EtchedBorder.RAISED, Color.white,
                                new Color(134, 134, 134));
    myTitledBorder = new TitledBorder(BrdStyle, Msg);
    this.setBorder(myTitledBorder);
    this.repaint();
  }
};

/**
 * Insert the type's description here.
 * Creation date: (00-04-28 ���� 1:42:39)
 * @author:
 */
 class Led extends Canvas {//VisibleCanvas {
	private java.awt.Color fieldTrueColor = new java.awt.Color(0);
	private java.awt.Color fieldFalseColor = new java.awt.Color(0);
	private boolean fieldStatus = false;
	private int LedType = 0;
/**
 * Led constructor comment.
 */
public Led() {
	super();
	initialize();
	LedType = 0;
}

public Led(Color LedTrue, Color LedFalse) {
	super();
	initialize();	
	setFalseColor(LedFalse);
	setTrueColor(LedTrue);		
	LedType = 1;
}
/**
 * Gets the falseColor property (java.awt.Color) value.
 * @return The falseColor property value.
 * @see #setFalseColor
 */
public java.awt.Color getFalseColor() {
	return fieldFalseColor;
}
/**
 * Gets the status property (boolean) value.
 * @return The status property value.
 * @see #setStatus
 */
public boolean getStatus() {
	return fieldStatus;
}
/**
 * Gets the trueColor property (java.awt.Color) value.
 * @return The trueColor property value.
 * @see #setTrueColor
 */
public java.awt.Color getTrueColor() {
	return fieldTrueColor;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		// user code end
		setName("Led");
		//setSize(20, 20);
		//setBounds(new Rectangle(50, 50, 20, 20));
		setFalseColor(java.awt.Color.red);
		//setTrueColor(java.awt.Color.gray);
		setTrueColor(java.awt.Color.green);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */

public static void main(java.lang.String[] args) {
	try {
		Frame frame = new java.awt.Frame();
		Led aLed;
		aLed = new Led();
		frame.add("Center", aLed);
		frame.setSize(aLed.getSize());
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			};
		});
		frame.setVisible(true);
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of demobeans.Led");
		exception.printStackTrace(System.out);
	}
}

public void paint(Graphics g) {
	Color dark, bright;
	Dimension size = getSize();
	if (fieldStatus == false) {
		dark = fieldFalseColor.darker().darker();
		bright = fieldFalseColor.brighter().brighter();
		dark = bright;
	} else {
		dark = fieldTrueColor.darker().darker();
		bright = fieldTrueColor.brighter().brighter();
		dark = bright;
	}
	int sgr = size.width < size.height ? size.width : size.height;
	int sx = 0;
	int sy = 0;
	g.setColor(Color.white);
	g.fillArc(sx, sy, sgr, sgr, 45, -180);
	g.setColor(new Color(128, 128, 128));
	g.fillArc(sx, sy, sgr, sgr, 45, 180);
	g.setColor(Color.black);
	g.fillOval(sx + 2, sy + 2, sgr - 4, sgr - 4);
	g.setColor(dark);
	g.fillOval(sx + 3, sy + 3, sgr - 6, sgr - 6);

	if (LedType == 1) {		 
		if (fieldStatus == true)
		{
			g.setColor(Color.white);
			g.drawArc(sx + 5, sy + 5, sgr - 12, sgr - 12, 85, 110);
			g.drawArc(sx + 6, sy + 6, sgr - 14, sgr - 14, 85, 130);
		}
	}
	else	{		
		g.setColor(Color.white);
		g.drawArc(sx + 5, sy + 5, sgr - 12, sgr - 12, 85, 110);
		g.drawArc(sx + 6, sy + 6, sgr - 14, sgr - 14, 85, 130);
	}
	

	g.setColor(bright);
	g.drawArc(sx + 4, sy + 4, sgr - 8, sgr - 8, 30, -160);
	g.drawArc(sx + 5, sy + 5, sgr - 10, sgr - 10, 30, -150);
	g.drawArc(sx + 6, sy + 6, sgr - 12, sgr - 12, 10, -80);
}
/**
 * Sets the falseColor property (java.awt.Color) value.
 * @param falseColor The new value for the property.
 * @see #getFalseColor
 */
void setFalseColor(java.awt.Color falseColor) {
	fieldFalseColor = falseColor;
}
public void setLed(boolean status) {
	setStatus(status);
	repaint();
}
/**
 * Sets the status property (boolean) value.
 * @param status The new value for the property.
 * @see #getStatus
 */
public void setStatus(boolean status) {
	fieldStatus = status;
}
/**
 * Sets the trueColor property (java.awt.Color) value.
 * @param trueColor The new value for the property.
 * @see #getTrueColor
 */
public void setTrueColor(java.awt.Color trueColor) {
	fieldTrueColor = trueColor;
}
}







